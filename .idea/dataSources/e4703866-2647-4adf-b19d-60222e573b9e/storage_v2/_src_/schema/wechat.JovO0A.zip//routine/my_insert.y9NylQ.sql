create
    definer = root@localhost procedure my_insert()
BEGIN
   DECLARE n int DEFAULT 1;
        loopname:LOOP
           insert into t_user(oppenid)VALUES(replace(UUID(),"-",""));
            SET n=n+1;
        IF n=10 THEN
            LEAVE loopname;
        END IF;
        END LOOP loopname;
END;

